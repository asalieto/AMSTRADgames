#ifndef _UTILS_H_
#define _UTILS_H_

#include <cpctelera.h>

extern const u8 bitMask[8];

extern void syncCounter();

// extern void printVar(u8 var, u8 x, u8 y);
extern void printNumber(u8 var, u8 x, u8 y);
extern void printNumberDigits(u8 var, u8 digits, u8 x, u8 y);
extern void printPointer(u16 var, u8 x, u8 y);
extern void printTime(u16 t, u8 x, u8 y);
extern u8 getBit(u16 position, u8* bytes);
extern void setBit(u8 val, u16 position, u8* bytes);
extern u8 max(u8 A, u8 B);
extern u8 min(u8 A, u8 B);
extern u8 absSubstract(u8 A, u8 B);
extern u8 posToByte(u8 x, u8 y);
// extern void printString(u8* string, u8 color, u8* memptr);

#endif