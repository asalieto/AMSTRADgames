#include "MapManager.h"
#include "Definitions.h"
#include "GlobalVars.h"

u8** const g_Map[4]={ 
	map_0,map_0,map_0,map_0
};

u8* const g_Map_Spawner[4]={
    map_0_spawn,map_0_spawn,map_0_spawn,map_0_spawn
};

u8* const g_Map_Keys[4]={
    map_0_objects,map_0_objects,map_0_objects,map_0_objects
};

u8** const g_Tiles[4]={ 
	mapTiles_0_tileset,mapTiles_0_tileset,mapTiles_0_tileset,mapTiles_0_tileset
};

const u8* g_Keys_video_position[4]={0};

void drawReconstructedTile(u8 x, u8 y, u8 index){
    u8* memptr;
    u8 randPos;
    y=((y-YOFFSET)&0xF0)+YOFFSET;
    memptr = cpct_getScreenPtr(VMEM, (x&0xFC),y);
    switch(index){
            case 0:
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][0],memptr);
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][0],memptr+2);
                memptr = cpct_getScreenPtr(VMEM, (x&0xFC),((y+8)&0xF0));
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][0],memptr);
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][0],memptr+2);
            break;
            case 1:
            randPos=(cpct_getRandomUniform_u8_f(g_inputCount)&3);
            
                cpct_drawTileAligned2x8_f((randPos==0?g_Tiles[g_currentLevel][1]:g_Tiles[g_currentLevel][0]),memptr);
                cpct_drawTileAligned2x8_f((randPos==1?g_Tiles[g_currentLevel][1]:g_Tiles[g_currentLevel][0]),memptr+2);
                memptr = cpct_getScreenPtr(VMEM, (x&0xFC),((y+8)&0xF0));
                cpct_drawTileAligned2x8_f((randPos==2?g_Tiles[g_currentLevel][1]:g_Tiles[g_currentLevel][0]),memptr);
                cpct_drawTileAligned2x8_f((randPos==3?g_Tiles[g_currentLevel][1]:g_Tiles[g_currentLevel][0]),memptr+2);
            break;
            case 2:
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][2],memptr);
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][3],memptr+2);
                memptr = cpct_getScreenPtr(VMEM, (x&0xFC),((y+8)&0xF0));
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][4],memptr);
                cpct_drawTileAligned2x8_f(g_Tiles[g_currentLevel][5],memptr+2);
            break;
            case 3:
                cpct_drawTileAligned2x8_f(g_blankTile,memptr);
                cpct_drawTileAligned2x8_f(g_blankTile,memptr+2);
                memptr = cpct_getScreenPtr(VMEM, (x&0xFC),((y+8)&0xF0));
                cpct_drawTileAligned2x8_f(g_blankTile,memptr);
                cpct_drawTileAligned2x8_f(g_blankTile,memptr+2);
            break;
    }
    
}

void getSpawnPosition(u8 index, u8* x, u8* y){
    u8 val=g_Map_Spawner[g_currentLevel][index];
    (*x)=(val%20)<<2;
    (*y)=((val/20)<<4)+YOFFSET;
}

void initKeyPos(){
    u8 n=(cpct_getRandomUniform_u8_f(g_inputCount)&3);
    u8 t;
    if(n!=0){
        t=g_Map_Keys[g_currentLevel][0];
        g_Keys_video_position[0]=cpct_getScreenPtr(VMEM, (t%20)<<2, ((t/20)<<4)+YOFFSET);
    }
    if(n!=1){
        t=g_Map_Keys[g_currentLevel][1];
        g_Keys_video_position[1]=cpct_getScreenPtr(VMEM, (t%20)<<2, ((t/20)<<4)+YOFFSET);
    }
    if(n!=2){
        t=g_Map_Keys[g_currentLevel][2];
        g_Keys_video_position[2]=cpct_getScreenPtr(VMEM, (t%20)<<2, ((t/20)<<4)+YOFFSET);
    }
    if(n!=3){
        t=g_Map_Keys[g_currentLevel][3];
        g_Keys_video_position[3]=cpct_getScreenPtr(VMEM, (t%20)<<2, ((t/20)<<4)+YOFFSET);
    }
}