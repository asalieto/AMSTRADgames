#include <types.h>

extern __at(0x0040) const u8 G_gameMusic[433];

extern __at(0x01F9) const u8 G_menuMusic[232];