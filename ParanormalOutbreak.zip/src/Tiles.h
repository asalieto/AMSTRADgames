#ifndef _TILES_H_
#define _TILES_H_

#include "sprites/mapTiles_0.h"
#include "sprites/numbers.h"
// #include "sprites/chars0.h"
// #include "sprites/chars1.h"
#include "sprites/Trap_notification.h"

#endif