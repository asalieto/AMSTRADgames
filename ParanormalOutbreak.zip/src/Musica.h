#ifndef _MUSICA_H_
#define _MUSICA_H_

#include <cpctelera.h>

extern void sonarMusicaMenu();
extern void sonarMusicaJuego();
extern void detenerCancion();
// extern void sonarEfecto();
// extern void detenerEfecto();

#endif