#include "GlobalVars.h"
#include "Definitions.h"

const u8 g_palette[2][4] = {
    {0, 25, 3, 6},
    {1, 23, 9, 10},
};

const u8 g_blankTile[16]={
    0x00,0x00,
    0x00,0x00,
    0x00,0x00,
    0x00,0x00,
    0x00,0x00,
    0x00,0x00,
    0x00,0x00,
    0x00,0x00,
};

const u8 g_lightedTile[16]={
    0xF0,0xF0,
    0xF0,0xF0,
    0xF0,0xF0,
    0xF0,0xF0,
    0xF0,0xF0,
    0xF0,0xF0,
    0xF0,0xF0,
    0xF0,0xF0,
};

const u8 g_undiscoveredMapColor=0x0F;
const u8 g_currentMap=0;
const u8 g_currentLevel=0;
const u8 g_currentExit=0;


const u8 g_inputCount=0;

const u8 gt_redrawMap=0;
const u8 gt_redrawPosition=0;
const u8 gt_clearSprites=1;

const u8 g_state =0;
const u8 g_changeState = 0;

const u8 g_frameCounterTimer = 0;
const u8 g_frameMenuTimer = 0;

const u16 g_gameTimer = LEVEL_DURATION;
const u8 g_menuOption = 0;

const u8 g_menuLastKey=255;
const u8 g_numKeys=3;

const u8 g_SYNC25=0;
const u8 g_SYNCMusic=0;

const u8 g_partidaCreada=0;
