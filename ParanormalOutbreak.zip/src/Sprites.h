#ifndef _SPRITES_H_
#define _SPRITES_H_

#include "sprites/ghost.h"
#include "sprites/human.h"
#include "sprites/flecha.h"
#include "sprites/llave.h"
#include "sprites/logo.h"
#include "sprites/trampa.h"
#include "sprites/logointro.h"

#endif