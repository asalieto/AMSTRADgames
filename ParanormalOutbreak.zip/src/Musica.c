#include "Definitions.h"
#include "GlobalVars.h"
#include "Utils.h"
#include "MapManager.h"
#include "Entities.h"

#include "musica/music.h"

void sonarMusicaMenu(){
    // Play next music 1/50 step.

    cpct_akp_musicPlay();
 
    // Loop de la cancion cuando acaba
    if (cpct_akp_songLoopTimes > 0){
        cpct_akp_musicInit(G_menuMusic);
    }
}

void sonarMusicaJuego(){
    // Play next music 1/50 step.
    cpct_akp_musicPlay();
        
    // Loop de la cancion cuando acaba
    if (cpct_akp_songLoopTimes > 0){
        cpct_akp_musicInit(G_gameMusic);
    }
}

void detenerCancion(){
    cpct_akp_stop();
}

// void sonarEfecto(){
    // Play next music 1/50 step.
    // cpct_akp_musicPlay();
// }

// void detenerEfecto(){
    // Play next music 1/50 step.
    // cpct_akp_musicPlay();
// }