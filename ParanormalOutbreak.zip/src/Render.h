#ifndef _RENDER_H_
#define _RENDER_H_

#include <cpctelera.h>

extern void drawMap();
extern void drawTile(u8 x, u8 y);
extern void drawOnPosition(u8 x, u8 y);
extern void renderInterfaceBg_Game();
extern void renderInterfaceClock_Game();

#endif