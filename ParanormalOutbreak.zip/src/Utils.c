#include "Utils.h"
#include "Definitions.h"
#include "Tiles.h"
#include "GlobalVars.h"
#include "Musica.h"

const u8 bitMask[8]={
    0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01
};

void syncCounter(){
    CONST_U8 g_SYNC25+=1;
    CONST_U8 g_SYNCMusic+=1;
    if(g_SYNCMusic==6 && g_state==GAME_STATE_GAME){
        sonarMusicaJuego();
        CONST_U8 g_SYNCMusic=0;
    }else if(g_SYNCMusic==6 && g_state!=GAME_STATE_GAME){
        sonarMusicaMenu();
        CONST_U8 g_SYNCMusic=0;
    }
}
// void printVar(u8 var, u8 x, u8 y){
    // u8* memptr;
    // char str[2]={'0','\0'};
    // var+='0';
    // str[0]=var;
    // memptr = cpct_getScreenPtr(VMEM, x,y);
    // printString(str,memptr,0,1);
    
// }

void printNumberDigits(u8 var, u8 digits, u8 x, u8 y){
    u8* memptr;
    u8 f=(var%10);
    u8 s=((var/10)%10);
    u8 t=((var/100)%10);
    memptr = cpct_getScreenPtr(VMEM, x,y);
    if(digits>2) cpct_drawTileAligned2x8_f(numbers_string_tileset[t],memptr);
    if(digits>1) cpct_drawTileAligned2x8_f(numbers_string_tileset[s],memptr+2);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[f],memptr+4);
}

void printNumber(u8 var, u8 x, u8 y){
    printNumberDigits(var,3,x,y);
}

void printPointer(u16 var, u8 x, u8 y){
    u8* memptr;
    u8 f=(var%10);
    u8 s=((var/10)%10);
    u8 t=((var/100)%10);
    u8 fo=((var/1000)%10);
    u8 fv=((var/10000)%10);
    memptr = cpct_getScreenPtr(VMEM, x,y);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[fv],memptr);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[fo],memptr+2);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[t],memptr+4);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[s],memptr+6);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[f],memptr+8);
}

void printTime(u16 t, u8 x, u8 y){
    u8* memptr;
    u8 m1,m0,s1,s0;
    //t/=50;
    s0=(t%10);
    s1=((t/10)%6);
    t/=60;
    m0=(t%10);
    m1=((t/10)%6);
    memptr = cpct_getScreenPtr(VMEM, x,y);
    
    cpct_drawTileAligned2x8_f(numbers_string_tileset[m1],memptr);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[m0],memptr+2);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[s1],memptr+6);
    cpct_drawTileAligned2x8_f(numbers_string_tileset[s0],memptr+8);
}

// void printString(u8* string, u8 color, u8* memptr){
    // if(string!=0){
        // switch(color){
            // case 0://Fondo negro letras amarillas
                // printPointer((u16)string,4,0);
                // while(*string!='\0'){
                    // switch(*string){
                        // case 'a':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[0],memptr);
                        // break;
                        // case 'b':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[1],memptr);
                        // break;
                        // case 'd':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[2],memptr);
                        // break;
                        // case 'e':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[3],memptr);
                        // break;
                        // case 'g':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[4],memptr);
                        // break;
                        // case 'i':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[5],memptr);
                        // break;
                        // case 'l':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[6],memptr);
                        // break;
                        // case 'm':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[7],memptr);
                        // break;
                        // case 'n':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[8],memptr);
                        // break;
                        // case 'o':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[9],memptr);
                        // break;
                        // case 'p':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[10],memptr);
                        // break;
                        // case 'r':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[11],memptr);
                        // break;
                        // case 's':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[12],memptr);
                        // break;
                        // case 't':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[13],memptr);
                        // break;
                        // case 'u':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[14],memptr);
                        // break;
                        // case 'v':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[15],memptr);
                        // break;
                        // case 'x':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[16],memptr);
                        // break;
                        // case 'A':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[17],memptr);
                        // break;
                        // case 'C':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[18],memptr);
                        // break;
                        // case 'E':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[19],memptr);
                        // break;
                        // case 'G':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[20],memptr);
                        // break;
                        // case 'I':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[21],memptr);
                        // break;
                        // case 'L':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[22],memptr);
                        // break;
                        // case 'M':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[23],memptr);
                        // break;
                        // case 'N':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[24],memptr);
                        // break;
                        // case 'O':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[25],memptr);
                        // break;
                        // case 'P':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[26],memptr);
                        // break;
                        // case 'R':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[27],memptr);
                        // break;
                        // case 'S':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[28],memptr);
                        // break;
                        // case 'T':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[29],memptr);
                        // break;
                        // case ':':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[30],memptr);
                        // break;
                        // case '#':
                            // cpct_drawTileAligned2x8_f(chars0_tileset[31],memptr);
                        // break;
                    // }
                    // string++;
                    // memptr+=2;
                // }
            // break;
            // case 1://Fondo amarillo letras negras
                // while(*string!='\0'){
                    // switch(*string){
                        // case 'a':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[0],memptr);
                        // break;
                        // case 'e':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[1],memptr);
                        // break;
                        // case 'i':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[2],memptr);
                        // break;
                        // case 'l':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[3],memptr);
                        // break;
                        // case 'm':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[4],memptr);
                        // break;
                        // case 'p':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[5],memptr);
                        // break;
                        // case 'r':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[6],memptr);
                        // break;
                        // case 's':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[7],memptr);
                        // break;
                        // case 'v':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[8],memptr);
                        // break;
                        // case 'L':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[9],memptr);
                        // break;
                        // case 'T':
                            // cpct_drawTileAligned2x8_f(chars1_tileset[10],memptr);
                        // break;
                    // }
                // string++;
                // memptr+=2;
                // }
            // break;
        // }
    // }
// }

u8 getBit(u16 position, u8* bytes){
    return bytes[position>>3]&bitMask[(position&7)];//Divido la posicion entre 8 (>>3) y le aplico una mascara que es el resultado de 1000 0000 movido a la derecha la posicion en modulo 8 (&7)
}

void setBit(u8 val, u16 position, u8* bytes){
    u8 shiftedpos=position>>3;
    bytes[shiftedpos]=(((bytes[shiftedpos])&(~bitMask[(position&7)]))|(val?bitMask[(position&7)]:0));//Divido la posicion entre 8 (>>3) y le aplico una mascara que es el resultado de 0111 1111 movido a la derecha la posicion en modulo 8 (&7), 
                                                                                                   //por ultimo le hago un OR con 1000 0000 movido a la derecha la posicion en modulo 8 (&7) si 'val'!=0 y 0 en caso contrario
}

u8 max(u8 A, u8 B){
    return (A>B?A:B);
}

u8 min(u8 A, u8 B){
    return (A<B?A:B);
}

u8 absSubstract(u8 A, u8 B){
    return (A>B?A-B:B-A);
}

u8 posToByte(u8 x, u8 y){
    return (x>>2)+(((y-YOFFSET)>>4)*20);
}
