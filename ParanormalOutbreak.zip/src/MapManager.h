#ifndef _MAPMANAGER_H_
#define _MAPMANAGER_H_

#include <cpctelera.h>
#include "Maps.h"
#include "Tiles.h"

extern u8** const g_Map[4];
extern u8* const g_Map_Spawner[4];
extern u8* const g_Map_Keys[4];
extern  u8** const g_Tiles[4];

extern const u8* g_Keys_video_position[4];
extern void drawReconstructedTile(u8 x, u8 y, u8 index);
extern void getSpawnPosition(u8 index, u8* x, u8* y);
extern void initKeyPos();

#endif