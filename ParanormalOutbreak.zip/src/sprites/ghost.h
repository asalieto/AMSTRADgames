// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _GHOST_H_
#define _GHOST_H_

#include <cpctelera.h>

extern u8* const ghost_tileset[4];
extern const u8 ghost_0[36];
extern const u8 ghost_1[36];
extern const u8 ghost_2[36];
extern const u8 ghost_3[36];

#endif