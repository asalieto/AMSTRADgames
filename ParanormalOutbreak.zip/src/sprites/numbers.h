// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _NUMBERS_H_
#define _NUMBERS_H_

#include <cpctelera.h>

extern u8* const numbers_string_tileset[10];
extern const u8 numbers_string_0[16];
extern const u8 numbers_string_1[16];
extern const u8 numbers_string_2[16];
extern const u8 numbers_string_3[16];
extern const u8 numbers_string_4[16];
extern const u8 numbers_string_5[16];
extern const u8 numbers_string_6[16];
extern const u8 numbers_string_7[16];
extern const u8 numbers_string_8[16];
extern const u8 numbers_string_9[16];

#endif
