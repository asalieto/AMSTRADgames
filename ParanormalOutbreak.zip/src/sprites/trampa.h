// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _TRAMPA_H_
#define _TRAMPA_H_

#include <cpctelera.h>

extern const u8 trap[64];

#endif
