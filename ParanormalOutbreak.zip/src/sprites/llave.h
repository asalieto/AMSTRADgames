// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _LLAVE_H_
#define _LLAVE_H_

#include <cpctelera.h>

extern const u8 llave[16];

#endif
