// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _HUMAN_H_
#define _HUMAN_H_

#include <cpctelera.h>

extern u8* const human_tileset[4];
extern const u8 human_0[36];
extern const u8 human_1[36];
extern const u8 human_2[36];
extern const u8 human_3[36];

#endif
