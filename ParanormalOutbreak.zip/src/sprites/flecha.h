// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _FLECHA_H_
#define _FLECHA_H_

#include <cpctelera.h>

extern u8* const flecha_tileset[1];
extern const u8 flecha[16];

#endif
