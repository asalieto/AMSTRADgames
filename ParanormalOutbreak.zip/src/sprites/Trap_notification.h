// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _TRAP_NOTIFICATION_H_
#define _TRAP_NOTIFICATION_H_

#include <cpctelera.h>

extern u8* const Trap_Indicator_tileset[4];
extern const u8 Trap_Indicator_0[16];
extern const u8 Trap_Indicator_1[16];
extern const u8 Trap_Indicator_2[16];
extern const u8 Trap_Indicator_3[16];

#endif
