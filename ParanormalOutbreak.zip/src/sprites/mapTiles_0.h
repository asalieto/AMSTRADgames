// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _MAPTILES_0_H_
#define _MAPTILES_0_H_

#include <cpctelera.h>

extern u8* const mapTiles_0_tileset[6];
extern const u8 mapTiles_0_0[16];
extern const u8 mapTiles_0_1[16];
extern const u8 mapTiles_0_2[16];
extern const u8 mapTiles_0_3[16];
extern const u8 mapTiles_0_4[16];
extern const u8 mapTiles_0_5[16];

#endif
