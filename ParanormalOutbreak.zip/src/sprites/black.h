// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _BLACK_H_
#define _BLACK_H_

#include <types.h>

extern u8* const black_tileset[1];

extern const u8 black[16];

#endif
