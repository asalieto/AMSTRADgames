// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _LOGO_H_
#define _LOGO_H_

#include <cpctelera.h>

extern u8* const logo_tileset[1];
extern const u8 logo[1800];

#endif
