#ifndef _LOGIC_H_
#define _LOGIC_H_

#include <cpctelera.h>
#include "Entities.h"

extern u8 getCollision(u8 x, u8 y);
extern u8 getCollisioninMap(u8 x, u8 y, u8 cmap);
extern u8 getCollisionDir(u8 x, u8 y, u8 dir);
extern u8 getCollisionDirMap(u8 x, u8 y, u8 dir, u8 cmap);
extern u8 getCollisionDirTile(u8 x, u8 y, u8 dir, u8 cmap);
extern u8 getCollisionByByte(u8 byte, u8 map);
extern u16 octogonalDistance(Vec2* PosA, Vec2* PosB);

#endif