#ifndef _MAP_0_H_
#define _MAP_0_H_

#include <cpctelera.h>

extern const u8 map_0_spawn[4];
extern const u8 map_0_objects[4];

extern u8* const map_0[4];
extern const u8 map_0_0[55];
extern const u8 map_0_1[55];
extern const u8 map_0_2[55];
extern const u8 map_0_3[55];

#endif