#ifndef _GLOBAL_VARS_H_
#define _GLOBAL_VARS_H_

#include <cpctelera.h>

extern const u8 g_palette[2][4];
extern const u8 g_blankTile[16];
extern const u8 g_lightedTile[16];
extern const u8 g_undiscoveredMapColor;
extern const u8 g_currentMap;
extern const u8 g_currentLevel;
extern const u8 g_currentExit;

extern const u8 g_inputCount; //Usado para el generador de RANDOM

extern const u8 gt_redrawMap;
extern const u8 gt_clearSprites;
extern const u8 gt_redrawPosition;

extern const u8 g_state;
extern const u8 g_changeState;
extern const u8 g_menuLastKey;

extern const u8 g_frameCounterTimer;
extern const u8 g_frameMenuTimer;
extern const u16 g_gameTimer;
extern const u8 g_menuOption;
extern const u8 g_numKeys;
extern const u8 g_partidaCreada;

extern const u8 g_SYNC25;
extern const u8 g_SYNCMusic;


#endif