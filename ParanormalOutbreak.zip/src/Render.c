#include "Render.h"
#include "Definitions.h"
#include "GlobalVars.h"
#include "Utils.h"
#include "MapManager.h"
#include "Sprites.h"
#include "Entities.h"

void drawMap(){
    u8* memptr;
    u8 i=0;
    u8 x,y;
    u8 tiles=0;
    u8 tileIndex=0;
    // cpct_clearScreen(g_undiscoveredMapColor);
    for(i;i<55;i++){
        x=((i%5)<<4);//Obtengo la columna del mapa y multiplico por 16 (<<4) para obtener el byte de la pantalla
        y=((i/5)<<4)+YOFFSET;//Obtengo la fila del mapa (i/5) y multiplico por 16 (<<4) para obtener el pixel en Y-24
            tiles=g_Map[g_currentLevel][g_currentMap][i];
            memptr = cpct_getScreenPtr(VMEM, x,y);
            if(getBit((i<<2)+(220*g_currentMap), g_Ghost.explored)){
                tileIndex=tiles>>6;//Filtro y muevo los 2 bits del primer indice al principio del byte
                drawReconstructedTile(x,y,tileIndex);
            }
            else{
                cpct_drawSolidBox(memptr, g_undiscoveredMapColor, 4,16);
                // drawReconstructedTile(x,y,3);//En caso de que no se haya explorado se pinta un cuadrado negro
            }
            if(getBit((i<<2)+1+(220*g_currentMap), g_Ghost.explored)){
                tileIndex=(tiles&0x30)>>4;//Filtro y muevo los 2 bits del segundo indice al principio del byte
                drawReconstructedTile(x+4,y,tileIndex);
            }
            else{
                cpct_drawSolidBox(memptr+4, g_undiscoveredMapColor, 4,16);
                // drawReconstructedTile(x+4,y,3);//En caso de que no se haya explorado se pinta un cuadrado negro
            }
            if(getBit((i<<2)+2+(220*g_currentMap), g_Ghost.explored)){
                tileIndex=(tiles&0x0C)>>2;//Filtro y muevo los 2 bits del tercer indice al principio del byte
                drawReconstructedTile(x+8,y,tileIndex);
            }
            else{
                cpct_drawSolidBox(memptr+8, g_undiscoveredMapColor, 4,16);
                // drawReconstructedTile(x+8,y,3);//En caso de que no se haya explorado se pinta un cuadrado negro
            }
            if(getBit((i<<2)+3+(220*g_currentMap), g_Ghost.explored)){
                tileIndex=(tiles&0x03);//Filtro los 2 bits del cuarto indice
                drawReconstructedTile(x+12,y,tileIndex);
            }
            else{
                cpct_drawSolidBox(memptr+12, g_undiscoveredMapColor, 4,16);
                // drawReconstructedTile(x+12,y,3);//En caso de que no se haya explorado se pinta un cuadrado negro
            }
    }
}

void drawTile(u8 x, u8 y){
    u8 b;
    u8* memptr;
    u16 position;
    if((x<80) && ((y<200)&&(y>=YOFFSET))){//Compruebo que el tile esta en esta parte
        position=posToByte(x,y)+(g_currentMap*220); //Divido Y-24 (Offset de la UI = 24) entre 16 (>>4) * multiplico por el numero de columnas (20), despues divido X entre 16 y lo sumo al resultado anterior,
                                                              //por ultimo le sumo 220 por la parte del mapa en la que estoy para obtener la posicion del tile en el mapa completo
        if(getBit(position, g_Ghost.explored)==0){ //Si no está explorado
        setBit(1,position,g_Ghost.explored);
        
        b=(5*((y-YOFFSET)>>4)) + (x>>4);//Obtengo la posicion del byte en el mapa
        b=g_Map[g_currentLevel][g_currentMap][b] & (0xC0>>(((x>>2)&3)<<1));//Filtro el byte y dejo solo los bits del pixel correspondiente
        b=b>>((3-((x>>2))&3)<<1);//Muevo los bits al principio del byte
        
        memptr = cpct_getScreenPtr(VMEM, (x&0xFC),((y-YOFFSET)&0xF0)+YOFFSET);
        drawReconstructedTile(x,y,b);
        }
    }
}

void drawOnPosition(u8 x, u8 y){
                                                                                     /*0*/drawTile((x-4),(y-48));  /*1*/drawTile((x),(y-48));  /*2*/drawTile((x+4),(y-48));
                                            /*3*/drawTile((x-8),(y-32)); /*4*/drawTile((x-4),(y-32));  /*5*/drawTile((x),(y-32));  /*6*/drawTile((x+4),(y-32));  /*7*/drawTile((x+8),(y-32));
    /*8*/drawTile((x-12),(y-16));/*9*/drawTile((x-8),(y-16));     drawTile((x-4),(y-16));        drawTile((x),(y-16));       drawTile((x+4),(y-16));  /*10*/drawTile((x+8),(y-16));  /*11*/drawTile((x+12),(y-16));
    /*12*/drawTile((x-12),(y));  /*13*/drawTile((x-8),(y));        drawTile((x-4),(y));          drawTile((x),(y));          drawTile((x+4),(y));     /*14*/drawTile((x+8),(y));     /*15*/drawTile((x+12),(y));
    /*16*/drawTile((x-12),(y+16));/*17*/drawTile((x-8),(y+16));     drawTile((x-4),(y+16));     drawTile((x),(y+16));       drawTile((x+4),(y+16));  /*18*/drawTile((x+8),(y+16));  /*19*/drawTile((x+12),(y+16));
                                             /*20*/drawTile((x-8),(y+32));/*21*/drawTile((x-4),(y+32));/*22*/drawTile((x),(y+32));/*23*/drawTile((x+4),(y+32));/*24*/drawTile((x+8),(y+32));
                                                                                    /*25*/drawTile((x-4),(y+48));  /*26*/drawTile((x),(y+48));/*27*/drawTile((x+4),(y+48));
}

void renderInterfaceBg_Game(){
    u8* memptr;
    memptr = cpct_getScreenPtr(VMEM, 0,0);
    //cpct_drawSolidBox(memptr, cpct_px2byteM1(2,2,1,1), 1, 24); //Borde izquierda
    //cpct_drawSolidBox(memptr+79, cpct_px2byteM1(1,1,2,2), 1, 24); //Borde derecha
    //cpct_drawSolidBox(memptr, cpct_px2byteM1(2,2,2,2), 40, 2); //Arriba 1/2
    //cpct_drawSolidBox(memptr+40, cpct_px2byteM1(2,2,2,2), 40, 2); //Arriba 2/2
    //memptr = cpct_getScreenPtr(VMEM, 0,22);
    //cpct_drawSolidBox(memptr, cpct_px2byteM1(2,2,2,2), 40, 2); //Abajo 1/2
    //cpct_drawSolidBox(memptr+40, cpct_px2byteM1(2,2,2,2), 40, 2); //Abajo 2/2
    //memptr = cpct_getScreenPtr(VMEM, 1,2);
    cpct_drawSolidBox(memptr, cpct_px2byteM1(1,1,1,1), 40, 24); //Centro 1/2
    cpct_drawSolidBox(memptr+40, cpct_px2byteM1(1,1,1,1), 40, 24); //Centro 2/2

    // Texto de la interfaz
    memptr = cpct_getScreenPtr(VMEM, 4,4);
    cpct_drawStringM1_f("Time",memptr,0,1);

    // Coloca el contador (00:00)
    printTime(g_gameTimer, 3, 16);

    memptr = cpct_getScreenPtr(VMEM, 19,4); 
    cpct_drawStringM1_f("Level",memptr,0,1);

    //Niveles
    printNumberDigits((g_currentLevel+1),1,19,16);

    memptr = cpct_getScreenPtr(VMEM, 60,8);
    cpct_drawStringM1_f("Trap",memptr,0,1);

    // Solid box de debajo de la llave
    memptr= cpct_getScreenPtr(VMEM, 34, 7);
    cpct_drawSolidBox(memptr, 0, 4, 12);

    // Icono de la llave
    memptr= cpct_getScreenPtr(VMEM, 35, 8);
    cpct_drawTileAligned2x8_f(llave, memptr);

    // x de las llaves
    memptr= cpct_getScreenPtr(VMEM, 39, 8);
    cpct_drawStringM1_f("x", memptr, 0, 1);

    // Contador de las llaves
    printNumberDigits((u8)g_numKeys,1,38,8);
}

void renderInterfaceClock_Game(){
    if(g_frameCounterTimer==0){
        // Coloca el contador (00:00)
        printTime(g_gameTimer, 3, 16);
    }
}