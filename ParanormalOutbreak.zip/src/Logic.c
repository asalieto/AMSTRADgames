#include "Logic.h"
#include "Definitions.h"
#include "GlobalVars.h"
#include "Utils.h"
#include "MapManager.h"

u8 getCollision(u8 x, u8 y){
    return getCollisioninMap(x,y,g_currentMap);
}

u8 getCollisioninMap(u8 x, u8 y, u8 cmap){
    u8 b;
    if(x>=80 && x<=167){//X no puede ser negativa, asi que a partir de 167 considero negativo
        x=0;
        if(g_currentMap==0) cmap=1;
        else if(g_currentMap==3) cmap=2;
        else return 1;
    }
    else if((x>167)){//de 167 a 255 considero < 0
        x=76;
        if(g_currentMap==1) cmap=0;
        else if(g_currentMap==2) cmap=3;
        else return 1;
    }
    if(y>=200){
        y=YOFFSET;
        if(g_currentMap==0) cmap=3;
        else if(g_currentMap==1) cmap=2;
        else return 1;
    }
    else if(y<YOFFSET){
        y=184;
        if(g_currentMap==3) cmap=0;
        else if(g_currentMap==2) cmap=1;
        else return 1;
    }
    b=(5*((y-YOFFSET)>>4)) + (x>>4);//Obtengo la posicion del byte en el mapa
    b=g_Map[g_currentLevel][cmap][b] & (0xC0>>(((x&0x0C))>>1));//Filtro el byte y dejo solo los bits del pixel correspondiente
    b=b>>((0x0C-(x&0x0C))>>1);//Muevo los bits al principio del byte
    return (b!=3);//Comparo los indices obtenidos con los designados como colision
}

u8 getCollisionByByte(u8 byte, u8 map){
    u8 b=byte>>2;
    b=g_Map[g_currentLevel][map][b] & (0xC0>>(((byte&0x03))<<1));//Filtro el byte y dejo solo los bits del pixel correspondiente
    b=b>>((0x03-(byte&0x03))<<1);//Muevo los bits al principio del byte
    return (b!=3);//Comparo los indices obtenidos con los designados como colision
}

u16 octogonalDistance(Vec2* PosA, Vec2* PosB){//Aproximación al valor de la distancia usando sumas y un bitshift http://gamedev.stackexchange.com/questions/69241/how-to-optimize-the-distance-function
    u16 dx,dy;
    dx=(absSubstract(PosA->x , PosB->x))*4;
    dy=(absSubstract(PosA->y , PosB->y));
    return ( (dx + dy + max(dx,dy))>>1 );
}

u8 getCollisionDir(u8 x, u8 y, u8 dir){
    return getCollisionDirMap(x,y,dir,g_currentMap);
}

u8 getCollisionDirMap(u8 x, u8 y, u8 dir, u8 cmap){
    switch(dir&0x0F){
        case 0x01://Arriba
            return (getCollisioninMap(x,y-1,cmap)||getCollisioninMap(x+2,y-1,cmap));
        case 0x02://Abajo
            return (getCollisioninMap(x,y+12,cmap)||getCollisioninMap(x+2,y+12,cmap));
        case 0x04://Derecha
            return (getCollisioninMap(x+3,y,cmap)||getCollisioninMap(x+3,y+11,cmap));
        case 0x08://Izquierda
            return (getCollisioninMap(x-1,y,cmap)||getCollisioninMap(x-1,y+11,cmap));
    }
    return 1;
}

u8 getCollisionDirTile(u8 x, u8 y, u8 dir, u8 cmap){//ESTOVA
    switch(dir&0x0F){
        case 0x01://Arriba
            return ((getCollisioninMap(x,((((y+11)-YOFFSET)&0xF0)+YOFFSET)-1,cmap)||getCollisioninMap(x+2,((((y+11)-YOFFSET)&0xF0)+YOFFSET)-1,cmap)));
        case 0x02://Abajo
            return ((getCollisioninMap(x,((((y)-YOFFSET)&0xF0)+YOFFSET)+16,cmap)||getCollisioninMap(x+2,((((y)-YOFFSET)&0xF0)+YOFFSET)+16,cmap)));
        case 0x04://Derecha
            return ((getCollisioninMap(((x)&0xFC)+4,y,cmap)||getCollisioninMap(((x)&0xFC)+4,y+11,cmap)));
        case 0x08://Izquierda
            return ((getCollisioninMap((((x+2)&0xFC)-1),y,cmap)||getCollisioninMap((((x+2)&0xFC)-1),y+11,cmap)));
    }
    return 1;
}